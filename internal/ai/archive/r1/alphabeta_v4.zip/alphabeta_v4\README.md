# AlphaBeta v4 – „Mobilitás + célfüggő célzás” (alphabeta-v4)

## Mi ez?

Az `alphabeta-v1` egy **pozíciósabb** változata: a célzó ágyú bónusza a
célpont típusától függ, és az ágyúk mobilitása is pontot ér. A varázsló-
fenyegetést továbbra is a `wizardDanger` kezeli.

## Hogyan választ lépést?

A keresés teljesen megegyezik a v1-vel; csak az értékelés más.

## Értékelés / heurisztikák

- anyag: varázsló 100, ágyú 12, gyalog 4;
- **buff +4 / nerf −4**;
- gyalog-előrehaladás: `rank/2`;
- **célfüggő célzási bónusz:**
  - gyalogra célozva **+3**,
  - ágyúra célozva **+8**,
  - varázslóra célozva **0** (ezt a `wizardDanger` 10-es értéke kezeli,
    így nincs dupla számolás);
- **ágyú-mobilitás: +1 minden üres szomszédos mezőért, max +4**;
- **varázsló-veszély: ágyú 10, gyalog 5, varázsló 2**;
- **tokenek: ±3**;
- végállás: ±1 000 000 − ply.

## Konfiguráció

Ugyanaz, mint a v1-nél.

## Bonyolultság és futásidő

A v1-ével közel azonos; az ágyú-mobilitás és a célzottípus-vizsgálat kis extra
számítás.

## Ismert gyengeségek

- A mobilitás és a célzási bónusz túlértékelése „szép” pozíciókhoz vezethet
  konkrét támadás helyett.
- A varázslóra célzó ágyú 0 bónuszt kap; ha a `wizardDanger` nem elég erős,
  alulértékelheti a közvetlen varázslófenyegetést.
- A tokenek ±3-as értéke agresszívabb teleportálásra ösztönözhet.

## Változások az előző verzióhoz képest

- **Célzó ágyú:** sík +7 → **célfüggő +3 / +8 / 0**.
- **Új tag:** ágyú-mobilitás +1/üres szomszéd, max +4.
- **Buff/nerf:** ±3 → **±4**.
- **Varázsló-veszély:** 9/5/2 → **10/5/2**.
- **Tokenek:** ±2 → **±3**.
- Cél: aktívabb ágyúk, pontosabb célválasztás.

## Futtatás és tesztelés

```bash
go test ./internal/ai/alphabeta_v4
go run ./cmd/selfplay -games 10 -a alphabeta-v4 -b alphabeta-v1 -depth 6 -nodes 0
```
