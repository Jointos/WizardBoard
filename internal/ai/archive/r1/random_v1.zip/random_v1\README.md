# Random v1 (random-v1)

## Mi ez?

A projekt legalapvetőbb baseline-ja: minden lépésnél **egyenletes
valószínűséggel** választ a legális lépések közül. Arra való, hogy minden
komolyabb motornak legyen egy könnyű ellenfele és egy viszonyítási pontja az
Elo-táblán.

## Hogyan választ lépést?

1. Megkapja a legális lépések listáját.
2. A seedelt `math/rand` generátorral kiválaszt egy indexet.
3. Visszaadja azt a lépést.

Nincs keresés, nincs kiértékelés.

## Értékelés / heurisztikák

Nincs. A motor kizárólag a véletlenre támaszkodik.

## Konfiguráció

Csak a `Seed` számít: ugyanazzal a seeddel ugyanazokat a lépéseket adja.
`MaxTime`, `MaxNodes`, `MaxDepth` hatástalan.

## Bonyolultság és futásidő

O(1) lépésválasztás. A leggyorsabb motor a mezőnyben.

## Ismert gyengeségek

- Nincs stratégiája, nem védekezik, nem támad tervszerűen.
- Az Elo-tábla alját adja; szinte mindenki ellen veszít.
- Jó arra, hogy a szimulációt és az arénát teszteljük vele.

## Változások az előző verzióhoz képest

**Első verzió.**

## Futtatás és tesztelés

```bash
go test ./internal/ai/random_v1
go run ./cmd/selfplay -games 10 -a random-v1 -b greedy-v1 -depth 6 -nodes 0
make arena-eval
```
