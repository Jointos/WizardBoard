// Package random_v1 plays a uniformly random legal action. It is the baseline
// every other engine must beat.
package random_v1

import (
	"math/rand"

	"wizardboardgame/internal/ai"
	"wizardboardgame/internal/game"
)

const ID = "random-v1"

func init() {
	ai.Register(ai.Info{
		ID:    ID,
		Name:  "Random v1",
		Notes: "Uniformly random legal action.",
	}, New)
}

type engine struct {
	rng *rand.Rand
}

func New(cfg ai.Config) ai.Engine {
	return &engine{rng: rand.New(rand.NewSource(cfg.Seed))}
}

func (e *engine) Name() string { return ID }

func (e *engine) Select(_ game.State, legal []game.Action) game.Action {
	return legal[e.rng.Intn(len(legal))]
}
