# AlphaBeta v1 (alphabeta-v1)

## Mi ez?

Klasszikus **negamax + alpha-béta** keresés transzpozíciós táblával (TT),
iteratív mélyítéssel és egy kifejezetten erre a játékra szabott kiértékeléssel.
Ez a projekt első „komoly” motorja, egyben az AI assist elemzésének motorja.

## Hogyan választ lépést?

1. A `game` csomagtól megkapja a legális lépések listáját.
2. **Jelölt-szűrés**: az ágyúk „mozgás + fordulás” kombinációiból csak azokat
   tartja meg, amelyek célba tudnak lőni vagy az ellenfél oldala felé néznek.
   Ez csökkenti az elágazást (cannon-fázisban ~250 → ~60-80).
3. A jelölteket a seedelt RNG-vel megkeveri (ízlések/versenyváltozatosság).
4. **Iteratív mélyítés** 1-től `MaxDepth`-ig. Minden mélységben a
   `searchRoot` megosztott alphával végigpróbálja a jelölteket; a legjobb
   lépést előre teszi a következő iterációhoz.
5. A `negamax` rekurzió:
   - terminális állás: `±(1 000 000 − ply)`,
   - TT-probe (exact / lower / upper bound),
   - lépésgenerálás a `game.State.Actions` újrafelhasznált bufferébe,
   - lépésrendezés: ütés/lövés elöl, majd TT-tipp,
   - alpha-béta cutoff.
6. Leállás: idő- (`MaxTime`) vagy node-korlát (`MaxNodes`), illetve `MaxDepth`.

## Értékelés / heurisztikák

A `evaluate` a **soron lévő** játékos szemszögéből pontoz:

- anyag: gyalog 4, ágyú 12, varázsló 100 (a varázsló a nyerési feltétel);
- buff +3, nerf −3 célpontonként;
- gyalog előrehaladása: `rank/2`;
- célzó ágyú: +7, ha lő egy ellenséget;
- varázsló-veszély: −9 ágyú, −5 gyalog, −2 varázsló fenyegetés;
- tokenek: +2/darab;
- végállás: ±1 000 000 (mélységkorrekcióval).

## Elemzés / AI assist

A csomag `Analyze` metódusa adja az assist listáját:

- a **★ engine lépés** ugyanazzal a kereséssel készül, mint az élő játék
  (fix 6-os mélység, dedikált node-büdzsé);
- a **top 10 alternatíva** szintén 6-os mélységen van pontozva;
- a 15 ponton belüli lépések pontos pontszámot kapnak, a távolabbiak `≤`
  felső korlátot;
- a node-büdzsé determinisztikus, ezért ismételt elemzés ugyanazt adja.

## Konfiguráció

| mező | élő játék | assist | aréna |
|---|---|---|---|
| `MaxTime` | 400 ms / 1500 ms / 2500 ms (fast/strong/max) | – | – |
| `MaxNodes` | – | belső büdzsé | 0 (nincs korlát) |
| `MaxDepth` | 8 | 6 | 6 |
| `Seed` | meccs + ply | 1 | játék-seed |

## Bonyolultság és futásidő

Alpha-béta + TT + jelölt-szűrés. A cannon-fázis a legdrágább; a fix 6-os
mélység tipikusan ~0,5–1,5 s/mozgás a fejlesztői gépen. Az assist teljes
elemzése ~3–5 s.

## Ismert gyengeségek

- A kiértékelés heurisztikus; hosszú távú terveket nem lát.
- A jelölt-szűrés ritkán jó „hátráló” ágyúmozgásokat is kiszűrhet.
- Nagy elágazású (cannon) állásban a mélység gyorsan csökken.
- A horizont-effektus miatt taktikai csapdákat néha nem lát meg.

## Változások az előző verzióhoz képest

**Első verzió.**

## Futtatás és tesztelés

```bash
go test ./internal/ai/alphabeta_v1
go run ./cmd/selfplay -games 10 -a alphabeta-v1 -b greedy-v1 -depth 6 -nodes 0
make arena-eval
```
