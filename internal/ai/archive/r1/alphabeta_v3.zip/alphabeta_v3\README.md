# AlphaBeta v3 – „Ágyú-offenzíva” (alphabeta-v3)

## Mi ez?

Az `alphabeta-v1` keresésének egy **agresszívabb, ágyú-központú**
értékeléssel rendelkező változata. Az ágyú a fő támadóerő, ezért többet ér, a
célzási bónusz nagyobb, a varázsló-veszély súlya pedig alacsonyabb — a motor
inkább támad, mint passzívan védekezik.

## Hogyan választ lépést?

A keresés teljesen megegyezik a v1-vel; csak az értékelés konstansai mások.

## Értékelés / heurisztikák

- anyag: varázsló 100, **ágyú 15**, gyalog 4;
- **buff +5 / nerf −5**;
- gyalog-előrehaladás: `rank/2`;
- **célzó ágyú: +10**;
- **varázsló-veszély: ágyú 7, gyalog 4, varázsló 2** (a v1 9/5/2-jénél
  alacsonyabb, hogy ne húzza vissza a támadást);
- tokenek: ±2;
- végállás: ±1 000 000 − ply.

## Konfiguráció

Ugyanaz, mint a v1-nél.

## Bonyolultság és futásidő

A v1-ével azonos.

## Ismert gyengeségek

- A csökkentett varázsló-veszély miatt **több wizard-blundert** követhet el.
- Az ágyúk túlértékelése miatt elhanyagolhatja a védelmet.
- Agresszív, de instabil; a v1 legyőzheti, ha kivédi a támadást.

## Változások az előző verzióhoz képest

- **Ágyú:** 12 → **15**.
- **Célzó ágyú bónusz:** +7 → **+10**.
- **Buff/nerf:** ±3 → **±5**.
- **Varázsló-veszély:** 9/5/2 → **7/4/2**.
- Minden más változatlan.
- Cél: aktívabb ágyúhasználat, több `cannon → wizard` ölés.

## Futtatás és tesztelés

```bash
go test ./internal/ai/alphabeta_v3
go run ./cmd/selfplay -games 10 -a alphabeta-v3 -b alphabeta-v1 -depth 6 -nodes 0
```
