# ML v1 (ml-v1)

## Mi ez?

Az `alphabeta-v4` keresésének (negamax + alpha-béta, transzpozíciós tábla,
iteratív mélyítés) egy változata, amelyben a **levél-kiértékelést** egy tanult
modell egészíti ki:

```
eval(position) = HandEval(position) + clamp(linearModel(features), -100, +100)
```

A `HandEval` a v4 kézzel írt értékelése (anyag, buff/nerf, gyalog-előrehaladás,
célzó ágyú, mobilitás, varázsló-veszély, tokenek). A lineáris modell a
**reziduális korrekciót** tanulja: mennyivel tér el a v4 depth-6 keresési
pontszáma a hand evaltól / mennyire jó a pozíció a kimenetel alapján.

A modell **ugyanaz** az engine és az AI assist számára, így a top lépés és az
értékelés konzisztens.

## Hogyan választ lépést?

A keresés teljesen megegyezik a v4-vel; csak a levél-kiértékelés más. A
jelölt-szűrés (ágyú mozgás+fordulás) **konfigurálható**:

- alapból **ki van kapcsolva** (a live/arena default nofilter),
- `DisableFilter: false` (vagy `-filter`) esetén bekapcsol.

## Feature-ök (24 db, oldal-relatív)

- anyag darabszám különbség típusonként (3),
- buff / nerf darabszám különbség típusonként (3+3),
- token-különbség (1),
- fázis one-hot (3),
- gyalog-előrehaladás különbség (1),
- célzó ágyúk száma (1),
- ágyú-mobilitás (1),
- varázsló-veszély különbség (1),
- bábuszám-különbség (1),
- hand eval / 100 (1),
- ply / MaxPly (1),
- pending (1),
- célzott típusok szerinti célzó ágyúk (3).

## Modell és tanítás

- **Modell:** 24 → 32 → 1 MLP (ReLU) vagy lineáris ridge; a súlyok a
  `weights.json`-ban, `go:embed`-del beágyazva. A tanító `-model linear|mlp`.
- **Adat:** `cmd/dataset` önjátszmákból (v1–v4, random/greedy nélkül) menti a
  pozíciókat. `-label outcome` esetén a címke a **játszma kimenetele** a soron
  lévő játékos szemszögéből (+1/0/−1); `-label score` esetén v4–v4 játszmákból
  a **v4 depth-6 keresési pontszáma** (sűrű címke).
- **Tanítás:** `cmd/train` játszma-szintű train/val/test split, standardizálás,
  Adam + early stopping (MLP) vagy ridge; a súlyokat a `weights.json`-ba írja.
- A `weights.json` placeholder (üres) esetén a korrekció 0, az engine a v4
  hand evaljével játszik.

## Konfiguráció

| mező | jelentés |
|---|---|
| `MaxTime` | időbüdzsé lépésenként (élő: 1,5 s) |
| `MaxDepth` | mélységkorlát (6) |
| `MaxNodes` | node-korlát (debug) |
| `Seed` | root shuffle seed |
| `DisableFilter` | kikapcsolja a jelölt-szűrést |

## Bonyolultság és futásidő

A tanult eval a hand eval + feature-számítás + lineáris predikció; néhány µs,
ezért a keresés mélysége a v4-hez hasonló. A modell tanítása másodpercek
(néhány százezer minta), az adatgenerálás a lassabb rész.

## Ismert gyengeségek

- A lineáris modell korlátozott; a nemlinearitásokat (pl. varázsló-veszély ×
  varázslók száma) nem tanulja meg.
- A kimenetel-alapú címke zajos; a v4 depth-6 pontszáma jobb, de drágább.
- A tanult korrekció a v4 hand evaljára épül; ha a hand eval hibás egy
  helyzetben, a modellnek kell korrigálnia.
- A jelölt-szűrés kikapcsolása mélyebb, de lassabb keresést jelent.

## Változások az előző verzióhoz képest

**Új motor** (nincs előző `ml` verzió). A v4 keresését használja, de a
levél-kiértékelést tanult korrekcióval egészíti ki; a jelölt-szűrés
konfigurálható.

## Futtatás és tesztelés

```bash
go test ./internal/ai/ml_v1
make dataset          # önjátszma adatok (v1-v4)
make train            # lineáris modell tanítása
make ml-eval          # aréna ml-v1 vs v1-v4
```
