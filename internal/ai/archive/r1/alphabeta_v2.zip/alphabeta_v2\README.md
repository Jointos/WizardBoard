# AlphaBeta v2 – „Első varázsló olcsó” (alphabeta-v2)

## Mi ez?

Az `alphabeta-v1` keresésének (negamax + alpha-béta, transzpozíciós tábla,
iteratív mélyítés, jelölt-szűrés) egy változata, **más anyagértékeléssel**: a
varázsló értéke attól függ, hány varázslója van még az adott oldalnak.

## Hogyan választ lépést?

A keresés teljesen megegyezik a v1-vel. A különbség kizárólag a levél-
kiértékelésben van: a varázslók anyagértéke nem fix 100, hanem:

- **2 élő varázsló:** 55 / db → összesen 110
- **1 élő varázsló:** 95 → összesen 95
- **0:** a játék véget ér (a terminál ±1 000 000-zel számol)

Így az **első varázsló elvesztése csak 15 pont**, a **második (utolsó) viszont
95** — az utolsó védelme a valódi prioritás.

## Értékelés / heurisztikák

A v1 összes többi tagja változatlan:

- anyag: gyalog 4, ágyú 12;
- buff +3 / nerf −3;
- gyalog-előrehaladás: `rank/2`;
- célzó ágyú: +7;
- varázsló-veszély: ágyú 9, gyalog 5, varázsló 2;
- tokenek: ±2;
- végállás: ±1 000 000 − ply.

## Konfiguráció

Ugyanaz, mint a v1-nél: `MaxTime` az élő játékban, `MaxNodes` az arénában /
assistban, `MaxDepth` (6 az arénában és az assistban), `Seed`.

## Bonyolultság és futásidő

A v1-ével azonos; az extra számítás csak a varázslók megszámlálása.

## Ismert gyengeségek

- Az első varázslót hajlamos lehet feláldozni; 1v2 varázslóhátrányba kerülve
  elveszítheti a meccset.
- A varázsló-veszély értékek változatlanok, tehát az első varázslót még mindig
  védi a `wizardDanger` — a hatás lehet, hogy kisebb a vártnál.
- A „jó kompenzáció” megítélése a keresés mélységétől függ.

## Változások az előző verzióhoz képest

- **Varázsló anyagérték:** fix 100 → **2 db esetén 55/db, 1 db esetén 95**.
- A többi érték változatlan.
- Cél: az első varázsló feláldozásának jutalmazása, az utolsó védelme.

## Futtatás és tesztelés

```bash
go test ./internal/ai/alphabeta_v2
go run ./cmd/selfplay -games 10 -a alphabeta-v2 -b alphabeta-v1 -depth 6 -nodes 0
```
