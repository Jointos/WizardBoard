// Package greedy_v1 is a one-ply materialistic baseline. It exists to prove the
// simulation hooks work and to give every new engine a sparring partner.
package greedy_v1

import (
	"wizardboardgame/internal/ai"
	"wizardboardgame/internal/game"
)

const ID = "greedy-v1"

func init() {
	ai.Register(ai.Info{
		ID:    ID,
		Name:  "Greedy v1",
		Notes: "One-ply material evaluation.",
	}, New)
}

type engine struct{}

func New(_ ai.Config) ai.Engine { return &engine{} }

func (e *engine) Name() string { return ID }

func (e *engine) Select(s game.State, legal []game.Action) game.Action {
	best := legal[0]
	bestScore := -1 << 30
	for _, a := range legal {
		ns, err := s.Apply(a)
		if err != nil {
			continue
		}
		score := Evaluate(&ns, s.Turn)
		if score > bestScore {
			bestScore = score
			best = a
		}
	}
	return best
}

// Value returns the material value of a unit.
func Value(t game.UnitType) int {
	switch t {
	case game.UnitWizard:
		return 100
	case game.UnitCannon:
		return 12
	case game.UnitPawn:
		return 4
	}
	return 0
}

// Evaluate scores a position for the given player.
func Evaluate(s *game.State, p game.Player) int {
	if s.Over {
		if s.Winner == game.NoPlayer {
			return 0
		}
		if s.Winner == p {
			return 100000
		}
		return -100000
	}
	score := 0
	for id := 0; id < game.MaxPieces; id++ {
		u := s.Pieces[id]
		if !u.Alive {
			continue
		}
		v := Value(u.Type)
		if s.IsBuffed(game.PieceID(id)) {
			v += 3
		}
		if s.IsNerfed(game.PieceID(id)) {
			v -= 3
		}
		if u.Owner == p {
			score += v
		} else {
			score -= v
		}
	}
	score += int(s.Token[p]) * 2
	score -= int(s.Token[p.Opponent()]) * 2
	return score
}
