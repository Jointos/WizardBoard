# Greedy v1 (greedy-v1)

## Mi ez?

Egy **egy lépéses, anyagelvű** baseline motor. Minden legális lépést
végrehajt, kiértékeli az így kapott állást, és a legjobb pontszámút választja.
Nincs keresés, nincs ellenfél-válasz modellezés.

## Hogyan választ lépést?

1. Végigmegy a legális lépéseken.
2. Mindegyikre meghívja a `game.State.Apply`-t.
3. A kapott állást a `Evaluate(&ns, s.Turn)` függvénnyel pontozza (a lépni
   akaró játékos szemszögéből).
4. A legmagasabb pontszámú lépést adja vissza. Holtverseny esetén az elsőt.

## Értékelés / heurisztikák

- anyag: gyalog 4, ágyú 12, varázsló 100;
- buff +3, nerf −3;
- tokenek: +2 saját, −2 ellenfél;
- végállás: ±100 000 (a nyertes oldal szemszögéből).

## Konfiguráció

Nem használ semmilyen `ai.Config` mezőt (`MaxTime`, `MaxNodes`, `MaxDepth`,
`Seed` mind hatástalan). Determinista.

## Bonyolultság és futásidő

O(legális lépések), jellemzően mikroszekundumok. Gyakorlatilag azonnal lép.

## Ismert gyengeségek

- Nem lát egy lépésnél tovább: nem veszi észre az ellenfél válaszát.
- Nem értékeli a pozíciót, a fenyegetéseket, a varázsló veszélyét.
- Hajlamos ingyen odaadni bábukat, ezért gyenge sparringpartner.

## Változások az előző verzióhoz képest

**Első verzió.**

## Futtatás és tesztelés

```bash
go test ./internal/ai/greedy_v1
go run ./cmd/selfplay -games 10 -a greedy-v1 -b random-v1 -depth 6 -nodes 0
make arena-eval
```
