# ML v2 (ml-v2)

## Mi ez?

Az `alphabeta-v4` keresésének (negamax + alpha-béta, transzpozíciós tábla,
iteratív mélyítés) továbbfejlesztett tanult kiértékelése. A v1-hez képest a
kézi értékelést **komponensekre bontja** (hand-eval breakdown), így a feature-ök
újraszámítás nélkül használhatják a részeket, és a modell **41 bemenetet** kap.

```
eval = HandParts.Total(side) + clamp(MLP(41 features), -100, +100)
```

A tanult korrekció a **v4 1,5 s-os keresési pontszáma − hand eval** reziduális,
v4–v4 önjátszmákból. A modell ugyanaz az engine és az AI assist számára.

## Hogyan választ lépést?

A keresés teljesen megegyezik a v4-vel. A jelölt-szűrés (ágyú mozgás+fordulás)
**alapból ki van kapcsolva** (a live/arena default nofilter); `DisableFilter:
false` / `-filter` kapcsolja be.

## Hand-eval breakdown

A `HandPartsOf(s)` egyszer számolja ki az összes komponenst (oldalanként):
anyag, buff, nerf, gyalog-előrehaladás, célzó ágyú (típusonként és értékkel),
mobilitás, varázsló-veszély (típusonként), tokenek, gyalog-készültség,
teleport-készültség, ágyú-irány, buffolt célzó ágyú, varázsló–ellenfél
távolságok. A `Total(turn)` adja a v4 hand evaljével azonos pontszámot.

## 41 feature

- anyag darabszám típusonként (3),
- buff / nerf darabszám típusonként (3+3),
- token, fázis one-hot, gyalog-előrehaladás (1+3+1),
- célzó ágyúk száma, mobilitás, varázsló-veszély (3),
- bábuszám, hand eval, ply, pending (4),
- célzott típusok (3), fenyegetéstípusok (3),
- gyalog-készültség, teleport-készültség (2),
- varázsló–ellenfél távolságok típusonként (3),
- ágyú-irány, üres mezők, buffolt célzó ágyú (3),
- hand-eval komponensek: anyag, buff, nerf, gyalog, célzás, mobilitás (6).

## Modell és tanítás

- **Modell:** 41 → 64 → 1 MLP (ReLU), Adam, early stopping; a súlyok
  `go:embed`-elve a `weights.json`-ban.
- **Adat:** `cmd/dataset_v2` v4–v4 önjátszma **1,5 s / depth 6**, nofilter;
  a címke a v4 keresési pontszáma − hand eval (sűrű reziduális).
- **Tanítás:** `cmd/train -target score -model mlp -hidden 64`.

## Konfiguráció

| mező | jelentés |
|---|---|
| `MaxTime` | időbüdzsé lépésenként (élő: 1,5 s) |
| `MaxDepth` | mélységkorlát (6) |
| `MaxNodes` | node-korlát (debug) |
| `Seed` | root shuffle seed |
| `DisableFilter` | jelölt-szűrés (alapból ki) |

## Bonyolultság és futásidő

A breakdown megszünteti a dupla varázsló-veszély/célzás/mobilitás számítást; a
41→64→1 MLP ~1–2 µs. Az eval így közelebb van a v4 hand evaljének költségéhez,
mint az ml-v1-ben.

## Ismert gyengeségek

- A modell a v4 1,5 s-os keresését **desztillálja**; önmagában nem tudja
  felülmúlni a tanárt.
- 500 v4–v4 játszma (~62k pozíció) kevés a legfinomabb mintázatokhoz.
- A feature-ök továbbra is aggregáltak; nincs teljes táblageometria.
- A tanult korrekció a hand evalra épül; ha a hand eval hibás, a modellnek kell
  korrigálnia.

## Változások az előző verzióhoz képest (ml-v1)

- **Hand-eval breakdown** bevezetése (nincs dupla komponens-számítás).
- **24 → 41 feature**: típusonkénti fenyegetések, gyalog-készültség,
  teleport-készültség, varázsló–ellenfél távolságok, ágyú-irány, üres mezők,
  buffolt célzó ágyú, hand-eval komponensek.
- **Tanári címkék 1,5 s-ról** (nem 500 ms), v4–v4 nofilter.
- **MLP 64 hidden** (a 32 helyett).
- A jelölt-szűrés alapból **ki** (a live/arena default nofilter).

## Eredmény (friss aréna)

- **ml-v2 vs v4, 30 játszma, mindkettő nofilter: 18-9-3 (0.650)**.
- ml-v2 vs v4, 30 játszma, filter on: **20-10 (0.667)**.
- ml-v2 vs v1 **10-0**, vs v2 **7-2-1**, vs v3 **8-2**.
- Fő Elo: **1329 (#1)**. A modell val MSE 1303.8 (zero 2086.2), MAE 17.8.

## Futtatás és tesztelés

```bash
go test ./internal/ai/ml_v2
make dataset-v2
make train-v2
make ml-v2-eval          # 30 games vs v4, filter off
make ml-v2-eval-filter   # 30 games vs v4, filter on
```
