package ml_v2

import (
	_ "embed"
	"encoding/json"
	"math"

	"wizardboardgame/internal/game"
)

//go:embed weights.json
var weightsJSON []byte

type layerWeights struct {
	In  int       `json:"in"`
	Out int       `json:"out"`
	W   []float64 `json:"w"`
	B   []float64 `json:"b"`
	Act string    `json:"act"`
}

type linearWeights struct {
	Version      int            `json:"version"`
	Type         string         `json:"type,omitempty"`
	FeatureCount int            `json:"featureCount"`
	Mean         []float64      `json:"mean"`
	Std          []float64      `json:"std"`
	Coef         []float64      `json:"coef"`
	Intercept    float64        `json:"intercept"`
	Scale        float64        `json:"scale,omitempty"`
	Layers       []layerWeights `json:"layers,omitempty"`
}

var model linearWeights

func init() {
	_ = json.Unmarshal(weightsJSON, &model)
}

const maxLayer = 64

func predict(x []float32) float64 {
	if len(x) != len(model.Mean) || len(x) != len(model.Std) {
		return 0
	}
	if model.Type == "mlp" {
		return predictMLP(x)
	}
	if len(x) != len(model.Coef) {
		return 0
	}
	z := model.Intercept
	for i, v := range x {
		sd := model.Std[i]
		if sd == 0 {
			sd = 1
		}
		z += model.Coef[i] * (float64(v) - model.Mean[i]) / sd
	}
	return z
}

func predictMLP(x []float32) float64 {
	if len(model.Layers) == 0 {
		return 0
	}
	var cur, next [maxLayer]float64
	n := len(x)
	if n > maxLayer {
		return 0
	}
	for i, v := range x {
		sd := model.Std[i]
		if sd == 0 {
			sd = 1
		}
		cur[i] = (float64(v) - model.Mean[i]) / sd
	}
	for _, l := range model.Layers {
		if l.In != n || l.Out <= 0 || l.Out > maxLayer || len(l.W) != l.In*l.Out || len(l.B) != l.Out {
			return 0
		}
		for o := 0; o < l.Out; o++ {
			sum := l.B[o]
			base := o * l.In
			for i := 0; i < l.In; i++ {
				sum += l.W[base+i] * cur[i]
			}
			if l.Act == "relu" && sum < 0 {
				sum = 0
			}
			next[o] = sum
		}
		copy(cur[:l.Out], next[:l.Out])
		n = l.Out
	}
	return cur[0]
}

// evaluate is the search's leaf evaluation: the hand breakdown plus the learned
// correction, clamped so a bad prediction cannot dominate.
func evaluate(s *game.State) int {
	if s.Over {
		return HandEval(s)
	}
	p := HandPartsOf(s)
	c := predict(FeaturesWithParts(s, p))
	if model.Scale != 0 {
		c *= model.Scale
	}
	if c > 100 {
		c = 100
	} else if c < -100 {
		c = -100
	}
	return p.Total(s.Turn) + int(math.Round(c))
}
